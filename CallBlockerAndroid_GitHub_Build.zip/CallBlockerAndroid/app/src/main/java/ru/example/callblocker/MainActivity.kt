package ru.example.callblocker

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var unknown: CheckBox
    private lateinit var hidden: CheckBox
    private lateinit var numberInput: EditText
    private lateinit var listText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshStatus()
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 10)
        }
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 36, 42, 36)
            setBackgroundColor(0xFFF5F6FA.toInt())
        }
        scroll.addView(layout)
        setContentView(scroll)

        layout.addView(TextView(this).apply {
            text = "☎  Блокировка вызовов"
            textSize = 25f
            setTextColor(0xFF172033.toInt())
        })
        status = TextView(this).apply {
            textSize = 14f
            setPadding(0, 18, 0, 18)
        }
        layout.addView(status)

        val activate = Button(this).apply {
            text = "Назначить приложением блокировки звонков"
            setOnClickListener { requestScreeningRole() }
        }
        layout.addView(activate)

        unknown = CheckBox(this).apply {
            text = "Блокировать номера не из контактов"
            textSize = 16f
            isChecked = prefs.getBoolean("unknown", true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("unknown", checked).apply() }
        }
        layout.addView(unknown)

        hidden = CheckBox(this).apply {
            text = "Блокировать скрытые / неизвестные caller ID"
            textSize = 16f
            isChecked = prefs.getBoolean("hidden", true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("hidden", checked).apply() }
        }
        layout.addView(hidden)

        layout.addView(TextView(this).apply {
            text = "Чёрный список"
            textSize = 20f
            setTextColor(0xFF172033.toInt())
            setPadding(0, 28, 0, 8)
        })
        numberInput = EditText(this).apply {
            hint = "Номер телефона, например +79991234567"
            textSize = 16f
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        layout.addView(numberInput)

        layout.addView(Button(this).apply {
            text = "Добавить номер"
            setOnClickListener {
                val number = numberInput.text.toString().trim()
                if (number.isBlank()) {
                    Toast.makeText(this@MainActivity, "Введите номер", Toast.LENGTH_SHORT).show()
                } else {
                    val current = prefs.getStringSet("blacklist", emptySet())!!.toMutableSet()
                    current.add(normalize(number))
                    prefs.edit().putStringSet("blacklist", current).apply()
                    numberInput.text.clear()
                    updateList()
                }
            }
        })
        listText = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFF333333.toInt())
            setPadding(0, 12, 0, 12)
        }
        layout.addView(listText)
        layout.addView(Button(this).apply {
            text = "Открыть настройки приложения"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = android.net.Uri.parse("package:$packageName")
                })
            }
        })
        updateList()
    }

    private fun requestScreeningRole() {
        val roleManager = getSystemService(RoleManager::class.java)
        if (roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
            if (!roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
                startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 20)
            } else {
                Toast.makeText(this, "Роль блокировки вызовов уже назначена", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "На этом устройстве роль Call Screening недоступна", Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshStatus() {
        val rm = getSystemService(RoleManager::class.java)
        status.text = if (rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING))
            "Статус: приложение назначено для фильтрации звонков"
        else "Статус: сначала назначьте приложение для фильтрации звонков"
    }

    override fun onResume() { super.onResume(); if (::status.isInitialized) refreshStatus() }

    private fun updateList() {
        if (!::listText.isInitialized) return
        val numbers = prefs.getStringSet("blacklist", emptySet())!!.sorted()
        listText.text = if (numbers.isEmpty()) "Список пуст" else numbers.joinToString("\n") { "• $it" }
    }

    companion object {
        fun normalize(s: String) = s.filter { it.isDigit() || it == '+' }
    }
}
