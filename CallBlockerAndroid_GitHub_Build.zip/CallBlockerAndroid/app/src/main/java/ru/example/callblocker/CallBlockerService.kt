package ru.example.callblocker

import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.TelecomManager
import android.net.Uri
import android.provider.ContactsContract
import android.content.Context

class CallBlockerService : CallScreeningService() {
    override fun onScreenCall(callDetails: Call.Details) {
        if (callDetails.callDirection != Call.Details.DIRECTION_INCOMING) {
            respondToCall(callDetails, CallResponse.Builder().build())
            return
        }

        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val handle = callDetails.handle
        val presentation = callDetails.handlePresentation
        val rawNumber = if (handle?.scheme == "tel") handle.schemeSpecificPart else null
        val normalized = rawNumber?.let { MainActivity.normalize(it) }

        val hiddenCall = rawNumber.isNullOrBlank() ||
            presentation == TelecomManager.PRESENTATION_RESTRICTED ||
            presentation == TelecomManager.PRESENTATION_UNKNOWN ||
            presentation == TelecomManager.PRESENTATION_PAYPHONE

        val blacklist = prefs.getStringSet("blacklist", emptySet()) ?: emptySet()
        val blacklisted = normalized != null && blacklist.any { numbersMatch(it, normalized) }
        val unknown = prefs.getBoolean("unknown", true) &&
            (normalized == null || !isInContacts(normalized))

        val shouldBlock = blacklisted ||
            (prefs.getBoolean("hidden", true) && hiddenCall) ||
            unknown

        val response = CallResponse.Builder()
            .setDisallowCall(shouldBlock)
            .setRejectCall(shouldBlock)
            .setSkipCallLog(false)
            .setSkipNotification(false)
            .build()
        respondToCall(callDetails, response)
    }

    private fun isInContacts(number: String): Boolean {
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return false
        }
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(number)
            )
            contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup._ID),
                null, null, null
            )?.use { it.moveToFirst() } ?: false
        } catch (_: Exception) {
            false
        }
    }

    private fun numbersMatch(a: String, b: String): Boolean {
        val aa = a.filter { it.isDigit() }
        val bb = b.filter { it.isDigit() }
        return aa == bb || (aa.length >= 7 && bb.length >= 7 && aa.takeLast(7) == bb.takeLast(7))
    }
}
